// This script helps clear browser cache
document.addEventListener('DOMContentLoaded', function() {
  // Force a hard reload if the page was loaded from cache
  if (performance.navigation.type === 2) {
    location.reload(true);
  }

  // Add a timestamp parameter to prevent caching
  const links = document.querySelectorAll('a');
  links.forEach(link => {
    if (link.href && link.href.startsWith(window.location.origin)) {
      link.addEventListener('click', function(e) {
        const timestamp = Date.now();
        const url = new URL(link.href);
        url.searchParams.set('t', timestamp);
        link.href = url.toString();
      });
    }
  });

  // Add cache control meta tags
  const metaNoCache = document.createElement('meta');
  metaNoCache.setAttribute('http-equiv', 'Cache-Control');
  metaNoCache.setAttribute('content', 'no-cache, no-store, must-revalidate');
  document.head.appendChild(metaNoCache);

  const metaPragma = document.createElement('meta');
  metaPragma.setAttribute('http-equiv', 'Pragma');
  metaPragma.setAttribute('content', 'no-cache');
  document.head.appendChild(metaPragma);

  const metaExpires = document.createElement('meta');
  metaExpires.setAttribute('http-equiv', 'Expires');
  metaExpires.setAttribute('content', '0');
  document.head.appendChild(metaExpires);
}); 